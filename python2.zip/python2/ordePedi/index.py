#! C:\Users\pasante\AppData\Local\Programs\Python\Python312\python.exe

print("Content-Type: text/html; charset=utf-8\n\r")


import cgi



from librerias.clasePaginaMenu import clasePaginaMenu
#from librerias.claseBaseDatos import *



form = cgi.FieldStorage()

laOpcion=0

if "opcion" in form:
	laOpcion = int(form["opcion"].value)
objeto = clasePaginaMenu()
presentar=objeto.presentaMenu(laOpcion)
print(presentar)
#print("hola")
