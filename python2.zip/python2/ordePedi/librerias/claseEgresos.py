#! C:\Users\pasante\AppData\Local\Programs\Python\Python312\python.exe
#from librerias.mmmm import conex
#from librerias.claseBaseDatos import mysqlConnect
import mysql.connector
import cgi
import cgitb
cgitb.enable()


class claseEgresos():
    def coneccion(self):
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="mro.ordenprueba"
        )
        return conexion
    def Articulo(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT codArticulo, articulo FROM articulo ORDER BY codArticulo"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        articulo = "<select id='articulo' style='width: 398px;'>"
        for registro in resultados:
            codArticulo = registro[0]
            articulo1 = registro[1]
            articulo += "<option value='" + str(codArticulo)+"'>" + articulo1 + "</option>"
        articulo += "</selec>"
        return articulo
    def ArticuloBodega(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT a.codArticulo, a.articulo, b.articuloDescripcion FROM articulo a, articulobodega b where a.codArticulo = b.codArticulo ORDER BY codArticulo"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        articulobodega = "<select id='articulodeBodega'>"
        for registro in resultados:
            codArticulo = registro[0]
            articulobode = registro[1]
            articulobodega += "<option value='" + str(codArticulo) + "' >" + articulobode + "</option>"
        articulobodega += "</select>"
        return articulobodega
    
    def Unidad(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT unidad, descripcion FROM unidad ORDER BY unidad"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        undd="<select id='UndMedida' >"
        for registro in resultados:
            unidad=registro[0]
            descripcion=registro[1]
            undd += "<option value='"+ str(unidad) +"' >" + descripcion + "</option>"
        undd += "</select>"
        return undd
    
    def CtaGastosAR(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT nroCompra, ar FROM ingbodegadetalle ORDER BY nroCompra"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        gastosAR ="<select id='CtaGastosA' style='width: 250px; background-color: #008080; text-align: center;'>"
        for registro in resultados:
            itemBodega=registro[0]
            ar=registro[1]
            gastosAR += "<option value='"+ ar +"' >" + ar + "</option>"
        gastosAR += "</select>"
        return gastosAR
    
    def Departamento(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT departamento, nombreDepartamento, usernameAprueba, abreviaDepartamento, grupo, apruebaEgreso FROM departamento ORDER BY departamento"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        textoSelect="<select id='txtDepartamento' style='width: 220px;'>"
        for registro in resultados:
            departamento=registro[0]
            nombreDepartamento=registro[1]
            textoSelect += "<option value='"+ str(departamento) +"' >" + nombreDepartamento + "</option>"
        textoSelect += "</select>"
        return textoSelect
    
    def tipoTrx(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT tipoTrx, clase, abrevia, descripcion, flagInventario, flagCompra FROM tipotrx ORDER BY tipoTrx"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        textotipo="<select id='txtTipoTRX' style='width: 220px;'>"
        for registro in resultados:
            idtipoTrx=registro[0]
            descripcion=registro[3]
            textotipo += " <option value='"+ str(idtipoTrx) + "' > " + descripcion + " </option>"
        textotipo += "</select>"
        return textotipo
    
    def bodega(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT codBodega, bodega, responsable, fchInicioInventario, estatus, grupo FROM bodega ORDER BY codBodega"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        textobodega="<select id='txtbodega' style='width: 220px;'>"
        for registro in resultados:
            codBodega=registro[0]
            bodega=registro[1]
            textobodega += " <option value='"+ str(codBodega) + "' > " + bodega + " </option>"
        textobodega += "</select>"
        return textobodega    

    def presentaEgresos(self):
        departamento = self.Departamento()
        textotipo = self.tipoTrx()
        textobodega = self.bodega()
        articulo = self.Articulo()
        articulobodega = self.ArticuloBodega()
        undd = self.Unidad()
        gastosAR = self.CtaGastosAR()
        presentar = f""" 
            <div >
                <p> 
                    <button class='w3-button w3-Teal w3-hover-grey' onclick='presentaPrimerRegistro();'>Primero</button>
                    <button class='w3-button w3-Teal w3-hover-grey' onclick='presentaSiguienteRegistro();'>Siguiente</button>
                    <button class='w3-button w3-Teal w3-hover-grey' onclick='presentaAnteriorRegistro();'>Anterior</button>
                    <button class='w3-button w3-Teal w3-hover-grey' onclick='presentaUltimoRegistro();'>Ultimo</button>
                    <button class='w3-button w3-Deep-Orange w3-hover-Yellow' onclick='Guardar();'>Guardar</button>
                    <button class='w3-button w3-Deep-Orange w3-hover-Yellow' onclick='Editar();'>Editar</button>
                    <button class='w3-button w3-Deep-Orange w3-hover-Yellow' onclick='readOnly();'>Habilitar fecha digitacion</button>
                </p>
                <table class='tabla' cellspacing='10'>
                    <tr>
                        <th> Egreso de Bodega Nro.: </th>
                        <td><input value='lblegresoNo' name='lblegresoNo' id='lblegresoNo' style='background-color:#3498db; color:blue;' type='int' readonly></td>
                    </tr>
                    <tr>
                        <th height='30'> departamento: </th>
                        <td>{departamento}</td>
                    </tr>
                    <tr>
                        <th> Tipo TRX: </th>
                        <td>{textotipo}</td>
                        <th > Fecha Digitacion </th>
                        <td> <input name='txtfechaDigitacion' id='txtfechaDigitacion' value='fechaDeHoy' readOnly> </td>
                    </tr>
                    <tr>
                        <th height='30'> Bodega: </th>
                        <td>{textobodega}</td>
                        <th style='width: 320px;'> Fecha Egre Bodega</th>
                        <td><input name='txtfechaegrebodg' id='txtfechaegrebodg'></td>
                    </tr>
                    <tr>
                        <th> Observacion: </th>
                        <td><input name='txtObservacion' id='txtObservacion' type='text'></td>
                    </tr>
                </table>
            </div>
            <div class='divMuestra' id='divMuestra'>
                
            </div>       
            <div> 
                <table class='grid2' id='tabla' cellspacing='10'>      
                    <tr> 
                        <th>Und.Medida:</th>   
                        <th>cantidad:</th>   
                        <th>Cta. Gastos / AR:</th>     
                    </tr>
                    <tr>
                        <td>{undd}</td>
                        <td><input id='cantidad' style='width: 398px;'></td>
                        <td>{gastosAR}</td>
                    </tr>
                    <tr>
                        <th>Articulo:</th>
                        <th>Articulo de Bodega:</th>
                        <th>Ubicacion:</th>    
                    </tr>
                    <tr>
                        <td>{articulo}</td>
                        <td>{articulobodega} </td>
                        <td><input id='Ubicacion' style='width: 250px;'></td>
                    </tr>
                    <tr>
                        <th>Referencia:</th>
                        <th>Descripcion:</th>  
                    </tr>
                    <tr>
                        <td><input type="text" id='referencia1' required></td>  
                        <td><input type="text" id='descripcion' required></td>
                    </tr>
                </table>
                <p>
                    <button class='w3-button w3-Deep-Orange w3-hover-Yellow' onclick='Agregar();'>Agregar</button>
                    <button class='w3-button w3-Deep-Orange w3-hover-Yellow' onclick='Eliminar();'>Eliminar</button>
                    <button class='w3-button w3-Deep-Orange w3-hover-Yellow' onclick='Renovar();'>Renovar</button>
                    <button class="w3-button w3-Deep-Orange w3-hover-Yellow" onclick='Actualizar();'>Actualizar</button>
                </p>  
            </div>
        """
        presentar += """
            <script>
                let primary=0;
                function presentaPrimerRegistro()
                {
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=presentaPrimerRegistro';
					var content = getContent(purl);
                    console.log(content);
                  // alert(content);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    primary=arreglo[0];
                    document.getElementById('lblegresoNo').value=arreglo[0];
                    document.getElementById('txtDepartamento').value=arreglo[1];
                    document.getElementById('txtTipoTRX').value=arreglo[2];
                    document.getElementById('txtbodega').value=arreglo[3];
                    document.getElementById('txtObservacion').value=arreglo[4];
                    document.getElementById('txtfechaDigitacion').value=arreglo[5];
                    document.getElementById('txtfechaegrebodg').value=arreglo[6];
                    presentarDetalle(primary);
                }
                function presentaSiguienteRegistro()
                {
                    parametro="&elPrimary="+primary;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=presentaSiguienteRegistro'+parametro;
					console.log(purl);
                    var content = getContent(purl);
                    console.log(content);
                //   alert(content);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    primary=arreglo[0];
                    document.getElementById('lblegresoNo').value=arreglo[0];
                    document.getElementById('txtDepartamento').value=arreglo[1];
                    document.getElementById('txtTipoTRX').value=arreglo[2];
                    document.getElementById('txtbodega').value=arreglo[3];
                    document.getElementById('txtObservacion').value=arreglo[4];
                    document.getElementById('txtfechaDigitacion').value=arreglo[5];
                    document.getElementById('txtfechaegrebodg').value=arreglo[6];
                    presentarDetalle(primary);
                }
                function presentaAnteriorRegistro()
                {
                    parametro="&elPrimary="+primary;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=presentaAnteriorRegistro'+parametro;
                    var content = getContent(purl);
                    console.log(content);
                //   alert(content);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    primary=arreglo[0];
                    document.getElementById('lblegresoNo').value=arreglo[0];
                    document.getElementById('txtDepartamento').value=arreglo[1];
                    document.getElementById('txtTipoTRX').value=arreglo[2];
                    document.getElementById('txtbodega').value=arreglo[3];
                    document.getElementById('txtObservacion').value=arreglo[4];
                    document.getElementById('txtfechaDigitacion').value=arreglo[5];
                    document.getElementById('txtfechaegrebodg').value=arreglo[6];
                    presentarDetalle(primary);
                }
                function presentaUltimoRegistro()
                {
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=presentaUltimoRegistro';
					var content = getContent(purl);
                    //alert(content);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    primary=arreglo[0];
                    document.getElementById('lblegresoNo').value=arreglo[0];
                    document.getElementById('txtDepartamento').value=arreglo[1];
                    document.getElementById('txtTipoTRX').value=arreglo[2];
                    document.getElementById('txtbodega').value=arreglo[3];
                    document.getElementById('txtObservacion').value=arreglo[4];
                    document.getElementById('txtfechaDigitacion').value=arreglo[5];
                    document.getElementById('txtfechaegrebodg').value=arreglo[6];
                    presentarDetalle(primary);
                }
                function presentarDetalle(elPrimary)
                {
                    parametro='&elPrimary='+elPrimary;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=presentaDetalleEgreso'+parametro;
					var content = getContent(purl);
                    divMuestra.innerHTML=content;
                }
                function Guardar()
                {
                    var departamento = document.getElementById('txtDepartamento').value;
                    var tipoTRX = document.getElementById('txtTipoTRX').value;
                    var bodega = document.getElementById('txtbodega').value;
                    var observacion = document.getElementById('txtObservacion').value;
                    var fechaDigitacion = document.getElementById('txtfechaDigitacion');
                    var fechaActual = new Date().toISOString().split('T')[0]; 
                    fechaDigitacion.value = fechaActual;
                    var fechaegreBodg = document.getElementById('txtfechaegrebodg').value;
                    var parametro = '&departamento=' + departamento + '&tipoTRX=' + tipoTRX + '&bodega=' + bodega + '&observacion=' + observacion + '&fechaDigitacion=' + fechaDigitacion.value + '&fechaegreBodg=' + fechaegreBodg;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=Guardar'+parametro;
                    var content = getContent(purl);
                    console.log(content);
                }
                function Agregar()
                {   
                    var idDepartamento = document.getElementById('lblegresoNo').value;
                    var UndMedida = document.getElementById('UndMedida').value;
                    var cantidad = document.getElementById('cantidad').value;
                    var ar = document.getElementById('CtaGastosA').value;
                    var articulo = document.getElementById('articulo').value;
                    var articulodeBodega = document.getElementById('articulodeBodega').value;
                    var Ubicacion = document.getElementById('Ubicacion').value;
                    var referencia1 = document.getElementById('referencia1').value;
                    var descripcion = document.getElementById('descripcion').value;
                    var parametro = '&idDepartamento='+ idDepartamento +'&UndMedida='+ UndMedida +'&cantidad='+ cantidad +'&ar='+ ar +'&articulo='+ articulo +'&articulodeBodega='+ articulodeBodega +'&Ubicacion='+ Ubicacion +'&referencia1='+ referencia1 +'&descripcion='+ descripcion;
                    console.log(parametro);
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=Agregar'+parametro;
                    var content = getContent(purl);
                    console.log(content);
                }
                function Eliminar()
                {
                    var idDepartamento = document.getElementById('lblegresoNo').value;
                    var parametro = '&idDepartamento=' + idDepartamento;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=Eliminar'+parametro;
                    var content = getContent(purl);
                    console.log(content);
                }
                function Renovar() {
                    parametro="&elPrimary="+primary;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=Renovar'+parametro;
					console.log(purl);
                    var content = getContent(purl);
                    console.log(content);
                //   alert(content);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    primary=arreglo[0];
                    document.getElementById('lblegresoNo').value=arreglo[0];
                    document.getElementById('UndMedida').value=arreglo[1];
                    document.getElementById('cantidad').value=arreglo[2];
                    document.getElementById('CtaGastosA').value=arreglo[3];
                    document.getElementById('articulo').value=arreglo[4];
                    document.getElementById('articulodeBodega').value=arreglo[5];
                    document.getElementById('Ubicacion').value=arreglo[6];
                    document.getElementById('referencia1').value=arreglo[7];
                    document.getElementById('descripcion').value=arreglo[8];
                }
                
                function Actualizar()
                {   
                    var idDepartamento = document.getElementById('lblegresoNo').value;
                    var UndMedida = document.getElementById('UndMedida').value;
                    var cantidad = document.getElementById('cantidad').value;
                    var ar = document.getElementById('CtaGastosA').value;
                    var articulo = document.getElementById('articulo').value;
                    var articulodeBodega = document.getElementById('articulodeBodega').value;
                    var Ubicacion = document.getElementById('Ubicacion').value;
                    var referencia1 = document.getElementById('referencia1').value;
                    var descripcion = document.getElementById('descripcion').value;                    
                    var parametro = '&idDepartamento='+ idDepartamento +'&UndMedida='+ UndMedida +'&cantidad='+ cantidad +'&ar='+ ar +'&articulo='+ articulo +'&articulodeBodega='+ articulodeBodega +'&Ubicacion='+ Ubicacion +'&referencia1='+ referencia1 +'&descripcion='+ descripcion;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=Actualizar'+parametro;
                    var content = getContent(purl);
                    console.log(content);
                } 
                function readOnly()
                {
                    var confirmacion = confirm('¿Está seguro de que desea editar la fecha de digitación?');
                    if (confirmacion) {
                        document.getElementById('txtfechaDigitacion').readOnly = false;
                    } else {
                        document.getElementById('txtfechaDigitacion').readOnly = true;
                    }
                }
                function Editar()
                {
                    var idDepartamento = document.getElementById('lblegresoNo').value;
                    var departamento = document.getElementById('txtDepartamento').value;
                    var tipoTRX = document.getElementById('txtTipoTRX').value;
                    var bodega = document.getElementById('txtbodega').value;
                    var observacion = document.getElementById('txtObservacion').value;
                    var fechaDigitacion = document.getElementById('txtfechaDigitacion').value;
                    document.getElementById('txtfechaDigitacion').readOnly=false;
                    var fechaegreBodg = document.getElementById('txtfechaegrebodg').value;
                    var parametro = '&idDepartamento=' + idDepartamento + '&departamento=' + departamento + '&tipoTRX=' + tipoTRX + '&bodega=' + bodega + '&observacion=' + observacion + '&fechaDigitacion=' + fechaDigitacion + '&fechaegreBodg=' + fechaegreBodg;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=Editar'+parametro;
                    console.log(purl);
                    var content = getContent(purl);
                    console.log(content);
                }
                function Agregar()
                {   
                    var idDepartamento = document.getElementById('lblegresoNo').value;
                    var UndMedida = document.getElementById('UndMedida').value;
                    var cantidad = document.getElementById('cantidad').value;
                    if(cantidad === ''){
                        alert('INGRESE LA CANTIDAD: este campo es obligatorio');                       
                    }
                    var ar = document.getElementById('CtaGastosA').value;
                    var articulo = document.getElementById('articulo').value;
                    var articulodeBodega = document.getElementById('articulodeBodega').value;
                    var Ubicacion = document.getElementById('Ubicacion').value;
                    if(Ubicacion === ''){
                        alert('INGRESE LA UBICACION: este campo es obligatorio');
                    }
                    var referencia1 = document.getElementById('referencia1').value;
                    if(referencia1 === ''){
                        alert('INGRESE LA REFERENCIA: este campo es obligatorio');
                    }
                    var descripcion = document.getElementById('descripcion').value;
                    if(descripcion === ''){
                        alert('INGRESE LA DESCRIPCION: este campo es obligatorio');
                    }
                    var parametro = '&idDepartamento='+ idDepartamento +'&UndMedida='+ UndMedida +'&cantidad='+ cantidad +'&ar='+ ar +'&articulo='+ articulo +'&articulodeBodega='+ articulodeBodega +'&Ubicacion='+ Ubicacion +'&referencia1='+ referencia1 +'&descripcion='+ descripcion;
                    console.log(parametro);
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=Agregar'+parametro;
                    var content = getContent(purl);
                    console.log(content);
                }
                function btnEditarDetalle(idDetalle)
                {
                    var parametro = '&idDetalle=' + idDetalle;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseEgresos&subPrograma=EditarDetalle'+parametro;
                    var content = getContent(purl);
                    console.log(content);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    document.getElementById('UndMedida').value=arreglo[0];
                    document.getElementById('cantidad').value=arreglo[1];
                    document.getElementById('CtaGastosA').value=arreglo[2];
                    document.getElementById('articulo').value=arreglo[3];
                    document.getElementById('articulodeBodega').value=arreglo[4];
                    document.getElementById('Ubicacion').value=arreglo[5];
                    document.getElementById('referencia1').value=arreglo[6];
                    document.getElementById('descripcion').value=arreglo[7];
                    disableObjects();               
                }
                function disableObjects()
                {
                    document.getElementById('UndMedida').disabled=false;
                    document.getElementById('UndMedida').style.background='#ffff33';
                    document.getElementById('cantidad').readOnly=true;
                    document.getElementById('cantidad').style.background='#ffff33';
                    document.getElementById('CtaGastosA').disabled=false;
                    document.getElementById('CtaGastosA').style.background='#ffff33';
                    document.getElementById('articulo').disabled=false;
                    document.getElementById('articulo').style.background='#ffff33';
                    document.getElementById('articulodeBodega').disabled=false;
                    document.getElementById('articulodeBodega').style.background='#ffff33'
                    document.getElementById('Ubicacion').readOnly=true;
                    document.getElementById('Ubicacion').style.background='#ffff33';
                    document.getElementById('referencia1').readOnly=true;
                    document.getElementById('referencia1').style.background='#ffff33';
                    document.getElementById('descripcion').readOnly='true';
                    document.getElementById('descripcion').style.background='#ffff33';
                }
                presentaUltimoRegistro();
            </script>
        """
        return presentar

    def presentaPrimerRegistro():
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Select nroEgreBodega, departamento, tipoTrx, codBodega, observacion, fechaEgreso, fechaEgrBodega from egrbodegaencabezado order by nroEgreBodega asc limit 1")
        myresult = mycursor.fetchall()
        texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_"
        for x in myresult:
            id=str(x[0])
            departamento=str(x[1])
            tipoTrx=str(x[2])
            codBodega=str(x[3])
            observacion=x[4]
            fechaEgreso=str(x[5])
            fechaEgreBodega=str(x[6])
            texto= "" + id + "_sc_" + departamento + "_sc_" + tipoTrx + "_sc_" + codBodega + "_sc_" + observacion + "_sc_" + fechaEgreso + "_sc_" + fechaEgreBodega + "_sc_"
        return texto
    
    def presentaSiguienteRegistro():
        form = cgi.FieldStorage()
        elPrimary = str(form["elPrimary"].value)
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Select nroEgreBodega, departamento, tipoTrx, codBodega, observacion, fechaEgreso, fechaEgrBodega from egrbodegaencabezado where nroEgreBodega > " + elPrimary + " order by nroEgreBodega asc limit 1")
        myresult = mycursor.fetchall()
        texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_"
        for x in myresult:
            id=str(x[0])
            departamento=str(x[1])
            tipoTrx=str(x[2])
            codBodega=str(x[3])
            observacion=x[4]
            fechaEgreso=str(x[5])
            fechaEgreBodega=str(x[6])
            texto= "" + id + "_sc_" + departamento + "_sc_" + tipoTrx + "_sc_" + codBodega + "_sc_" + observacion + "_sc_" + fechaEgreso + "_sc_" + fechaEgreBodega + "_sc_"
        return texto
    
    def presentaAnteriorRegistro():
        form = cgi.FieldStorage()
        elPrimary = str(form["elPrimary"].value)
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Select nroEgreBodega, departamento, tipoTrx, codBodega, observacion, fechaEgreso, fechaEgrBodega FROM egrbodegaencabezado where nroEgreBodega < " + elPrimary + " order by nroEgreBodega desc limit 1")
        myresult = mycursor.fetchall()
        texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_"
        for x in myresult:
            id=str(x[0])
            departamento=str(x[1])
            tipoTrx=str(x[2])
            codBodega=str(x[3])
            observacion=x[4]
            fechaEgreso=str(x[5])
            fechaEgreBodega=str(x[6])
            texto= "" + id + "_sc_" + departamento + "_sc_" + tipoTrx + "_sc_" + codBodega + "_sc_" + observacion + "_sc_" + fechaEgreso + "_sc_" + fechaEgreBodega + "_sc_"
        return texto
    
    def presentaUltimoRegistro():
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Select nroEgreBodega, departamento, tipoTrx, codBodega, observacion, fechaEgreso, fechaEgrBodega from egrbodegaencabezado order by nroEgreBodega desc limit 1")
        myresult = mycursor.fetchall()
        texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_"
        for x in myresult:
            id=str(x[0])
            departamento=str(x[1])
            tipoTrx=str(x[2])
            codBodega=str(x[3])
            observacion=x[4]
            fechaEgreso=str(x[5])
            fechaEgreBodega=str(x[6])
            texto= "" + id + "_sc_" + departamento + "_sc_" + tipoTrx + "_sc_" + codBodega + "_sc_" + observacion + "_sc_" + fechaEgreso + "_sc_" + fechaEgreBodega + "_sc_"
        return texto
    def presentaDetalleEgreso():
        form = cgi.FieldStorage()
        elPrimary= str(form["elPrimary"].value)
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT e.idtrx, a.articulo, e.cantidad, e.ar, e.ubicacion, e.referencia FROM egrbodegadetalle e, articulo a where e.codArticulo=a.codArticulo AND e.idtrx="+ elPrimary +" ORDER BY idtrx")
        myresult = mycursor.fetchall()
        lista= "" 
        for x in myresult:
            id=str(x[0])
            codArticulo=x[1]
            cantidad=str(x[2])
            ar=x[3]
            ubicacion=x[4]
            referencia=x[5]
            lista += "<tr>"
            lista +="<td> <button id=btn_'"+ id +"' onclick='btnEditarDetalle("+ id +");'>Editar </button></td> "
            lista += "<td id='id'>"  + id + "</td>" 
            lista += "<td>" + codArticulo + "</td>" 
            lista += "<td>" + cantidad + "</td>"
            lista += "<td>" + ar + "</td>"
            lista += "<td>" + ubicacion + "</td>"
            lista += "<td>" + referencia + "</td>"
            lista +="</tr>"
        presenta = "<table border='1'>"
        presenta += "<tr>"
        presenta += "<th>Accion</th>" 
        presenta += "<th>Item Bodega</th>" 
        presenta += "<th>Articulo</th>"
        presenta += "<th>Cantidad</th>"
        presenta += "<th>AR</th>"
        presenta += "<th>Ubicacion</th>"
        presenta += "<th>Referencia</th>"
        presenta +="</tr>"
        presenta += lista
        presenta += "</table>"
        return presenta
        
    def Guardar():
        form = cgi.FieldStorage()
        #id = form.getvalue("idProveedor")
        departamento = form.getvalue("departamento")
        tipoTRX = form.getvalue("tipoTRX")
        Bodega = form.getvalue("bodega")
        observacion = form.getvalue("observacion")
        fechaDigitacion = form.getvalue("fechaDigitacion")
        fechaegreBodg = form.getvalue("fechaegreBodg")
        #return departamento, tipoTRX, Bodega, observacion, fechaDigitacion, fechaegreBodg
        coneccion = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = coneccion.cursor()
        sql = "INSERT INTO egrbodegaencabezado (departamento, tipoTrx, codBodega, observacion, fechaEgreso, fechaEgrBodega) VALUES (%s, %s, %s, %s, %s, %s)"
        values = (departamento, tipoTRX, Bodega, observacion, fechaDigitacion, fechaegreBodg)
        mycursor.execute(sql, values)
        coneccion.commit()  
        return values

    def Agregar():
        form = cgi.FieldStorage()
        idDepartamento = form.getvalue("idDepartamento")
        UndMedida = form.getvalue("UndMedida")
        cantidad = form.getvalue("cantidad")
        ar = form.getvalue("ar")
        articulo = form.getvalue("articulo")
        articulodeBodega = form.getvalue("articulodeBodega")
        Ubicacion = form.getvalue("Ubicacion")
        referencia1 = form.getvalue("referencia1")
        descripcion = form.getvalue("descripcion")
        #return idDepartamento, UndMedida, cantidad, ar, articulo, articulodeBodega, Ubicacion, referencia1, descripcion  
        coneccion = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = coneccion.cursor()
        sql = "INSERT INTO egrbodegadetalle (nroEgreBodega, itemBodega, descripcionBodega, cantidad, unidad, codArticulo, referencia, codArtBod, ar, ubicacion) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        values = (idDepartamento, idDepartamento, descripcion, cantidad, UndMedida, articulo, referencia1, articulodeBodega, ar, Ubicacion)
        mycursor.execute(sql, values)
        coneccion.commit()  
        return values        
    
    def Actualizar():
        form = cgi.FieldStorage()
        idDepartamento = form.getvalue('idDepartamento')
        UndMedida = form.getvalue('UndMedida')
        cantidad = form.getvalue('cantidad')
        ar = form.getvalue('ar')
        articulo = form.getvalue('articulo')
        articulodeBodega = form.getvalue('articulodeBodega')
        Ubicacion = form.getvalue('Ubicacion')
        referencia1 = form.getvalue('referencia1')
        descripcion = form.getvalue('descripcion')
        #return idProveedor, UndMedida, cantCom, cantBod, Oracle1, Oracle2, ar, articulodeBodega, referencia1, descripcion, ubicacion, total
        conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='mro.ordenprueba'
        )
        cursor = conexion.cursor()
        cursor.execute("Update egrbodegadetalle SET descripcionBodega=%s, cantidad=%s, unidad=%s, codArticulo=%s, referencia=%s, codArtBod=%s, ar=%s, ubicacion=%s WHERE idtrx=%s", (descripcion, cantidad, UndMedida, articulo, referencia1, articulodeBodega, ar, Ubicacion, idDepartamento))
        conexion.commit()
        conexion.close()
        return 'Se actualizo'
    
    def Renovar():
        form = cgi.FieldStorage()
        elPrimary = str(form["elPrimary"].value)
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Select idtrx, unidad, cantidad,  ar, codArticulo, codArtBod, ubicacion, referencia, descripcionBodega from egrbodegadetalle where idtrx > " + elPrimary + " order by idtrx asc limit 1")
        myresult = mycursor.fetchall()
        texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_" + "_sc_"
        for x in myresult:
            lblegresoNo=str(x[0])
            UndMedida=str(x[1])
            cantidad=str(x[2])
            CtaGastosA=x[3]
            articulo=str(x[4])
            articulodeBodega=str(x[5])
            Ubicacion=[6]
            referencia1=x[7]
            descripcion=x[8]
            texto= "" +lblegresoNo + "_sc_" + UndMedida + "_sc_" + cantidad + "_sc_" + CtaGastosA + "_sc_" + articulo + "_sc_" + articulodeBodega +"_sc_"+ Ubicacion +"_sc_" + referencia1 + "_sc_" + descripcion + "_sc_"
            print(texto)
        return texto
    def Eliminar():
        form = cgi.FieldStorage()
        idDepartamento = form.getvalue("idDepartamento")
        #return idProveedor
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="mro.ordenprueba"
        )
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM egrbodegadetalle WHERE idtrx IN (SELECT nroEgreBodega FROM egrbodegaencabezado WHERE nroEgreBodega=%s)",(idDepartamento))
        conexion.commit()
        conexion.close()
        return 'Se elimino exitosamente'
        
    def Editar():
        form = cgi.FieldStorage()
        idDepartamento = form.getvalue("idDepartamento")
        departamento = form.getvalue("departamento")
        tipoTRX = form.getvalue("tipoTRX")
        Bodega = form.getvalue("bodega")
        observacion = form.getvalue("observacion")
        fechaDigitacion = form.getvalue("fechaDigitacion")
        fechaegreBodg = form.getvalue("fechaegreBodg")
        #return idDepartamento, departamento, tipoTRX, Bodega, observacion, fechaDigitacion, fechaegreBodg
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("UPDATE egrbodegaencabezado SET departamento=%s, tipoTrx=%s, codBodega=%s, observacion=%s, fechaEgreso=%s, fechaEgrBodega=%s WHERE nroEgreBodega=%s", (departamento, tipoTRX, Bodega, observacion, fechaDigitacion, fechaegreBodg, idDepartamento))
        mydb.commit()
        return mycursor
    
    def EditarDetalle():
        form = cgi.FieldStorage()
        idDetalle= form.getvalue("idDetalle")
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT  idtrx, unidad, cantidad, ar, codArticulo, codArtBod, ubicacion, referencia, descripcionBodega FROM egrbodegadetalle WHERE idtrx="+ idDetalle +" limit 1 ")
        myresult = mycursor.fetchall()
        texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_" + "_sc_"
        #return texto
        for x in myresult:
            UndMedida=str(x[1])
            cantidad=str(x[2])
            CtaGastosA=x[3]
            articulo=str(x[4])
            articulodeBodega=str(x[5])
            Ubicacion=x[6] 
            referencia1=x[7]
            descripcion=x[8]
            texto = ""+UndMedida+ "_sc_" +cantidad+ "_sc_" +CtaGastosA+ "_sc_" +articulo+ "_sc_" +articulodeBodega+ "_sc_" +Ubicacion+ "_sc_" +referencia1+ "_sc_" +descripcion+ "_sc_"
        return texto