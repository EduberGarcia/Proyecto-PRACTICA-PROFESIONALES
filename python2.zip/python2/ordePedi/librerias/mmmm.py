class eddy ():
    def calcular_perimetro(self, lado):
       

        perimetro = 4 * lado
        return perimetro


def main():
    lado = 10
    n = eddy()
    perimetro = n.calcular_perimetro(lado)
    print(f"El perímetro del cuadrado es {perimetro}.")


if __name__ == "__main__":
    eddy()
    main()


    #def Ingbodegaencabezado(self):
    #    conexion = self.coneccion()
    #    cursor = conexion.cursor()
    #    consulta = "SELECT nroIngBodega, proveedor,	fechaIngrBodega, status, username, usernameAprobo1, fechaAprobo1, horaAprobo1, observacion, tipoTrx, codBodega, fechaIngreso, fechaLLegadaBodega FROM ingbodegaencabezado ORDER BY nroIngBodega"
    #    cursor.execute(consulta)
    #    resultados = cursor.fetchall()
    #    cursor.close()
    #    textofechaIngrBodega = "<select id=''>"
    #    for registro in resultados:
    #        nroIngBodega=registro[0]
    #        fechaIngrBodega = registro[2].strftime('%Y-%m-%d')
    #        textofechaIngrBodega += " <option name='txtfechaIngBodega' id='txtfechaIngBodega' value='"+ str(nroIngBodega) + "' > " + str(fechaIngrBodega) + " </option>"
    #    textofechaIngrBodega += "</select>"
    #    return textofechaIngrBodega