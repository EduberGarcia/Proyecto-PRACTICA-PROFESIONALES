#! C:\Users\pasante\AppData\Local\Programs\Python\Python312\python.exe

from librerias.claseIngresos import claseIngresos
from librerias.claseEgresos import claseEgresos
class clasePaginaMenu():

	def presentaMenu(self,opcion):
		presentarOpcion=""
		if opcion == 3001:
			elObjeto = claseIngresos()
			presentarOpcion=elObjeto.presentaIngresos()
		elif opcion == 4001:
			elObjeto= claseEgresos()
			presentarOpcion=elObjeto.presentaEgresos()
		presentar =("""
			<!DOCTYPE >
				<html lang='es'>
				<head>
				<meta charset='UTF-8'>
				<title>WebOrdepedi</title>
				<meta name='viewport' content='width=device-width, initial-scale=1'>
			  	<link rel='stylesheet' href='css/estilo.css'>
			  	<link rel='stylesheet' href='css/estilo1.css'>
				<link rel='stylesheet' href='css/w3.css'>
				<link rel='stylesheet' href='css/font-awesome-min.css'>				
				<link rel='stylesheet' href='css/jquery-ui.css'>
			
				<script src='css/jquery-1.11.1.js'></script>  
				<script src='css/jquery-ui.js'></script>	
				</head>			
				<header class='w3-container w3-Indigo'>
					<span class='w3-opennav w3-xlarge w3-cyan' onclick='w3_open()' >&#9776;</span>					
					<div class='w3-row'>
					  <div class='w3-third w3-container'>					 
					    <h2>Galapesca - nombreBodega</h2> 
					  </div>
					  <div class='w3-third w3-container w3-center'>
					    <h1>WEB - Ordenes Pedido</h1> 
					  </div>
					  <div class='w3-third w3-container w3-right-align'>
					    <button type='submit' onclick='muestraLogin();' class='w3-btn w3-blue w3-medium'><i class='fa fa-user fa-2x'  aria-hidden='true'></i><p id='nombreUsuario' onclick='opcionLogin();' class='w3-tooltip'>nombreUsuario <span class='w3-text'>(<em>Cambiar Contrasena</em>)</span></p></button>
					  </div>
					</div>		
			  	</header>

				<body>
					<div class='w3-container'>
						<div id='id01' class='w3-modal'>
							<div class='w3-modal-content w3-card-8 w3-animate-zoom' style='max-width:600px'>			
								<div class='w3-center'><br>
									<span onclick='document.getElementById(\"id01\").style.display=\"none\"' class='w3-closebtn w3-hover-red w3-container w3-padding-8 w3-display-topright' title='Close Modal'>&times;</span>
									<img src='./librerias/imagenes/img_avatar3.png' alt='Avatar' style='width:30%' class='w3-circle w3-margin-top'>
								</div>			
								<form class='w3-container' >
									<div class='w3-section'>
										<label><b>Usuario</b></label>
										<input id='txtUsuario' class='w3-input w3-border w3-margin-bottom' type='text' placeholder='Enter Username' name='usrname'   required >
										<label><b>Password</b></label>
										<input id='txtPassword' class='w3-input w3-border' type='password' placeholder='Enter Password' name='psw'  required>
										<button class='w3-btn-block w3-green w3-section w3-padding' type='button' onclick='revisaLogin();'>Login</button>			      
									</div>
								</form>			
								<div class='w3-container w3-border-top w3-padding-16 w3-light-grey'>
									<button onclick='document.getElementById(\"id01\").style.display=\"none\" ' type='button' class='w3-btn w3-red'>Cancel</button>			        
								</div>			
							</div>
						</div>

						<div id='id02' class='w3-modal'>
							<div class='w3-modal-content w3-card-8 w3-animate-zoom' style='max-width:600px'>			
								<div class='w3-center'><br>
									<span onclick='document.getElementById(\"id02\").style.display=\"none\"' class='w3-closebtn w3-hover-red w3-container w3-padding-8 w3-display-topright' title='Close Modal'>&times;</span>
									<img src='./librerias/imagenes/img_avatar3.png' alt='Avatar' style='width:30%' class='w3-circle w3-margin-top'>
								</div>			
								<form class='w3-container' >
									<div class='w3-section'>
									<label><b>Nueva Contrasena</b></label>
									<input id='txtPassword2' class='w3-input w3-border' type='password' placeholder='Ingrese nueva Contrasena' name='psw1'  required>
									<label><b>Reintente Nueva Contrasena</b></label>
									<input id='txtPassword3' class='w3-input w3-border' type='password' placeholder='Ingresar otra vez nueva Contrasena' name='psw2'  required>
									<button class='w3-btn-block w3-green w3-section w3-padding' type='button' onclick='cambiaContrasena();'>Cambiar</button>			      
									</div>
								</form>			
							</div>
						</div>							
					</div>
	
				<nav class='w3-sidenav w3-white  w3-card-2' style='display:none; width:15%;' id='mySidenav'>
				  <a href='javascript:void(0)' onclick='w3_close()'
				  class='w3-closenav w3-xlarge'>Cerrar &times;</a>
				  <div class='w3-accordion' >
				  	<a id='submenu5' class=' w3-medium w3-Khaki '  href='./?opcion=1005'>
				      Seleccion 
				    </a>
				  	<a id='submenu1' style='visibility:$displayMenu1;' onclick='miSubmenu1()' href='#'>
				      Solicitudes <i class='fa fa-caret-down'></i>
				    </a>
				    <div id='demoAcc' class='w3-accordion-content w3-pale-green w3-card-4'>
				      <a href='./index.py?opcion=2001'>Egresos de Bodega</a>
				    </div>
				    <a id='submenu2' style='visibility:$displayMenu2;' onclick='miSubmenu2()' href='#'>
				      Ingreso Bodega<i class='fa fa-caret-down'></i>
				    </a>
				    <div id='demoAcc2' class='w3-accordion-content w3-pale-blue w3-card-4'>
				      <a href='./index.py?opcion=3001'>Ingresos</a>	
			  		  <a href='./index.py?opcion=3002'>Movimientos</a>				      				      
				    </div>
				    <a id='submenu3' style='visibility:$displayMenu3;' onclick='miSubmenu3()' href='#'>
				      Egreso Bodega<i class='fa fa-caret-down'></i>
				    </a>
				    <div id='demoAcc3' class='w3-accordion-content w3-pale-red w3-card-4'>
				      <a href='./index.py?opcion=4001'>Egresos</a>
			  		  <a href='./index.py?opcion=4002'>Movimientos</a>
				    </div>
				    <a id='submenu4' style='visibility:$displayMenu4;' onclick='miSubmenu4()' href='#'>
				      Inventarios<i class='fa fa-caret-down'></i>
				    </a>
				    <div id='demoAcc4' class='w3-accordion-content w3-pale-yellow w3-card-4'>
				      <a href='./index.py?opcion=5001' >Inventarios</a>
				      <a href='./index.py?opcion=5002' >Movimientos</a>
				      <a href='./index.py?opcion=5003' >Resumen General</a>
				    </div>
				    <a id='submenu5' style='visibility:$displayMenu5;' onclick='miSubmenu5()' href='#'>
				      Tablas Sistema<i class='fa fa-caret-down'></i>
				    </a>
				    <div id='demoAcc5' class='w3-accordion-content w3-pale-blue w3-card-4'>
				      <a href='./index.py?opcion=6001'>A</a>
				      <a href='./index.py?opcion=6002'>B</a>
				    </div>
				    <a id='submenu6' style='visibility:$displayMenu6;' onclick='miSubmenu6()' href='#'>
				      Eventuales<i class='fa fa-caret-down'></i>
				    </a>
				    <div id='demoAcc6' class='w3-accordion-content w3-pale-cyan w3-card-4'>
				    	<a href='./index.py?opcion=7001'>C</a>
				    	<a href='./index.py?opcion=7002'>D</a>
				    </div>
				    <a id='submenu9' class=' w3-large w3-orange'  href='./?opcion=9001'>
				      Salir del Sistema &times;
				    </a>
				  </div>
				 
				</nav>
				
				
								  
				<script language='javaScript'>
				
						$(document).ready(function() {
						    $('form').keypress(function(e) {
						        if (e.which == 13) {
						            return false;
						        }
						    });
						});	
				
				
					var opcionMuestraLogin=0;
					function w3_open() {
					    document.getElementById('mySidenav').style.display = 'block';
					}
					function w3_close() {
					    document.getElementById('mySidenav').style.display = 'none';
					}
					function miSubmenu1() {
					    var x = document.getElementById('demoAcc');
					    if (x.className.indexOf('w3-show') == -1) {
					        x.className += ' w3-show';
					        x.previousElementSibling.className += ' w3-green';
					    } else {
					        x.className = x.className.replace(' w3-show', '');
					        x.previousElementSibling.className =
					        x.previousElementSibling.className.replace(' w3-green', '');
					    }
					}				
					function miSubmenu2() {
					    var x = document.getElementById('demoAcc2');
					    if (x.className.indexOf('w3-show') == -1) {
					        x.className += ' w3-show';
					        x.previousElementSibling.className += ' w3-blue';
					    } else {
					        x.className = x.className.replace(' w3-show', '');
					        x.previousElementSibling.className =
					        x.previousElementSibling.className.replace(' w3-blue', '');
					    }
					}
					function miSubmenu3() {
					    var x = document.getElementById('demoAcc3');
					    if (x.className.indexOf('w3-show') == -1) {
					        x.className += ' w3-show';
					        x.previousElementSibling.className += ' w3-red';
					    } else {
					        x.className = x.className.replace(' w3-show', '');
					        x.previousElementSibling.className =
					        x.previousElementSibling.className.replace(' w3-red', '');
					    }
					}
					function miSubmenu4() {
					    var x = document.getElementById('demoAcc4');
					    if (x.className.indexOf('w3-show') == -1) {
					        x.className += ' w3-show';
					        x.previousElementSibling.className += ' w3-pink';
					    } else {
					        x.className = x.className.replace(' w3-show', '');
					        x.previousElementSibling.className =
					        x.previousElementSibling.className.replace(' w3-pink', '');
					    }
					}
					function miSubmenu5() {
					    var x = document.getElementById('demoAcc5');
					    if (x.className.indexOf('w3-show') == -1) {
					        x.className += ' w3-show';
					        x.previousElementSibling.className += ' w3-teal';
					    } else {
					        x.className = x.className.replace(' w3-show', '');
					        x.previousElementSibling.className =
					        x.previousElementSibling.className.replace(' w3-teal', '');
					    }
					}
					function miSubmenu6() {
					    var x = document.getElementById('demoAcc6');
					    if (x.className.indexOf('w3-show') == -1) {
					        x.className += ' w3-show';
					        x.previousElementSibling.className += ' w3-cyan';
					    } else {
					        x.className = x.className.replace(' w3-show', '');
					        x.previousElementSibling.className =
					        x.previousElementSibling.className.replace(' w3-cyan', '');
					    }
					}
					function miSubmenu7() {
					    var x = document.getElementById('demoAcc7');
					    if (x.className.indexOf('w3-show') == -1) {
					        x.className += ' w3-show';
					        x.previousElementSibling.className += ' w3-amber';
					    } else {
					        x.className = x.className.replace(' w3-show', '');
					        x.previousElementSibling.className =
					        x.previousElementSibling.className.replace(' w3-amber', '');
					    }
					}
					function getContent(sURL)
					{
						var xmlhttp;
						if(window.XMLHttpRequest)
						{
							xmlhttp = new XMLHttpRequest();
							xmlhttp.open(\"GET\", sURL, false);
							xmlhttp.send(null);
						}
						else if (window.ActiveXObject)
						{
							xmlhttp = new ActiveXObject(\"Microsoft.XMLHTTP\");
							if(xmlhttp)
							{
								xmlhttp.open(\"GET\", sURL, false);
								xmlhttp.send();
							}
						}
						var content=xmlhttp.responseText;
						return content;
					}
					function sleep(milliseconds) {
					//  document.getElementById('divPresenta1').style.display='block';

					  var start = new Date().getTime();
					  for (var i = 0; i < 1e7; i++) {
					    if ((new Date().getTime() - start) > milliseconds){
					      break;
					    }
					  }
					}	
					function opcionLogin()
					{
						opcionMuestraLogin=1;
					}
					function muestraLogin()
					{
						if (opcionMuestraLogin == 1)
							document.getElementById('id02').style.display='block';
						else
							document.getElementById('id01').style.display='block';
					}
					function revisaLogin()
					{
						var txtUsuario = document.getElementById('txtUsuario').value;
						var txtPassword = escape(document.getElementById('txtPassword').value);
				//		alert(txtPassword);
						var purl='./librerias/claseBuscar.php?action=ejecutarAJAX&programa=claseUsuario&subPrograma=buscaUsuario&txtUsuario='+txtUsuario+'&txtPassword='+txtPassword;
						var content = getContent(purl);						
						var arreglo = content.split('_sc_');
					//	alert(content);
						if (arreglo[0].length==0)
						{
							alert('Usuario no registrado, intente nuevamente');
							return;
						}
						document.getElementById('id01').style.display='none';
						var idUsuario = arreglo[0];
						document.getElementById('nombreUsuario').innerHTML = arreglo[1];
				//		alert(txtLocalidad);	
						document.location=\"./?opcion=1000 \";
					}
					function cambiaContrasena()
					{
						var txtUsuario = '$idUser';
						var txtPassword2 = document.getElementById('txtPassword2').value;
						var txtPassword3 = document.getElementById('txtPassword3').value;
					//	alert(txtUsuario);
						if (txtPassword2.length == 0)
						{
							alert('Por favor ingrese una contraseña correcta');
							return;
						}
						if (txtPassword2 != txtPassword3)
						{
							alert('Las nuevas contrasenas no coinciden, intente de nuevo por favor');
							return;
						}
						var purl='./librerias/claseBuscar.php?action=ejecutarAJAX&programa=claseUsuario&subPrograma=cambiaContrasena&txtUsuario='+txtUsuario+'&txtPassword2='+txtPassword2+'&txtPassword3='+txtPassword3;
						var content = getContent(purl);
					//	alert(content);							
						var arreglo = content.split('_sc_');
						
						if (arreglo[0].length==0)
						{
							alert('Usuario no registrado, intente nuevamente');
							return;
						}
						document.getElementById('id02').style.display='none';
				//		var idUsuario = arreglo[0];
				//		document.getElementById('nombreUsuario').innerHTML = arreglo[1];
				//		alert(txtLocalidad);	
						document.location=\"./ \";
					}
					
				</script>
	  
        """)
		presentar = presentar + presentarOpcion
		return presentar
	
	def otroMetodo(self):
		print("test")
		presentar="hola desde otro Metodo"
		return presentar
	
