
#import mysql.connector


class claseBaseDatos():



    def conectarse(self):
    #    servidor=""
    #    usuario=""
    #    contrasena=""
    #    base=""
    #    conexion = mysql.connector.connect( 
    #        user = 'root',
    #       host = 'localhost',  
    #        #paswword="",
    #        database = 'prueba',
    #        port ="3306",
    #    )
        return ""

    