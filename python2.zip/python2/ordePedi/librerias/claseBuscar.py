#! C:\Users\pasante\AppData\Local\Programs\Python\Python312\python.exe

import cgi
from claseIngresos import *
from claseEgresos import *
#from claseBaseDatos import * 


print("Content-Type: text/html; charset=utf-8\n\r")
#print("Esto es una prueba ClaseBuscar ")
form = cgi.FieldStorage()


if "action" in form:
	if form["action"].value == "ejecutarAJAX":
		programa = form["programa"].value
		subPrograma = form["subPrograma"].value 
		x=eval(programa + "." + subPrograma + "()")
		print(x)








