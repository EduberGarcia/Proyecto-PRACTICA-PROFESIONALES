#! C:\Users\pasante\AppData\Local\Programs\Python\Python312\python.exe
#from librerias.mmmm import conex
#from librerias.claseBaseDatos import mysqlConnect
import mysql.connector
import cgi
import cgitb
cgitb.enable()


class claseIngresos():
    def coneccion(self):
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="mro.ordenprueba"
        )
        return conexion
    def ArticuloBodega(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT a.codArticulo, a.articulo, b.articuloDescripcion FROM articulo a, articulobodega b where a.codArticulo = b.codArticulo ORDER BY codArticulo"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        articulobodega = "<select id='articulodeBodega'>"
        for registro in resultados:
            codArticulo = registro[0]
            articulobode = registro[1]
            articulobodega += "<option value='" + str(codArticulo) + "' >" + articulobode + "</option>"
        articulobodega += "</select>"
        return articulobodega
    
    def Unidad(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT unidad, descripcion FROM unidad ORDER BY unidad"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        undd="<select id='UndMedida1' style='width:400px; background-color: #008080; text-align: center;'>"
        for registro in resultados:
            unidad=registro[0]
            descripcion=registro[1]
            undd += "<option value='"+ str(unidad) +"' >" + descripcion + "</option>"
        undd += "</select>"
        return undd
    def Oracle1(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta ="SELECT oracleuno FROM presup ORDER BY oracleuno"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        oracleuno="<select id='Oracle1' style='width:200px; background-color: #008080; text-align: center;'>"
        for registro in resultados:
            ora=registro[0]
            oracleuno += "<option value='"+ (ora)+"'>" + ora +"</option>"
        oracleuno +="</select>"
        return oracleuno
    
    def Oracle2(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta ="SELECT oracledos FROM presup ORDER BY oracledos"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        oracledos="<select id='Oracle2' style='width:395px; background-color: #008080; text-align: center;'>"
        for registro in resultados:
            ora=registro[0]
            oracledos += "<option value='"+ (ora)+"'>" + ora +"</option>"
        oracledos +="</select>"
        return oracledos
    
    def Proveedor(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT nombre FROM proveedor "
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        textoSelect="<select id='txtProveedor' style='width: 220px;'>"
        for registro in resultados:
            proveedor=registro[0]
            textoSelect += "<option value='"+ (proveedor) +"'  >" + proveedor + "</option>"
        textoSelect += "</select>"
        return textoSelect
    
    def tipoTrx(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT tipoTrx, clase, abrevia, descripcion, flagInventario, flagCompra FROM tipotrx ORDER BY tipoTrx"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        textotipo="<select id='txtTipoTRX' style='width: 220px;'>"
        for registro in resultados:
            idtipoTrx=registro[0]
            descripcion=registro[3]
            textotipo += " <option value='"+ str(idtipoTrx) + "' > " + descripcion + " </option>"
        textotipo += "</select>"
        return textotipo
    
    def bodega(self):
        conexion = self.coneccion()
        cursor = conexion.cursor()
        consulta = "SELECT codBodega, bodega, responsable, fchInicioInventario, estatus, grupo FROM bodega ORDER BY codBodega"
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        cursor.close()
        textobodega="<select id='txtbodega' style='width: 220px;'>"
        for registro in resultados:
            codBodega=registro[0]
            bodega=registro[1]
            textobodega += " <option value='"+ str(codBodega) + "' > " + bodega + " </option>"
        textobodega += "</select>"
        return textobodega    

    def presentaIngresos(self):
        proveedor = self.Proveedor()
        textotipo = self.tipoTrx()
        textobodega = self.bodega()
        articulobodega = self.ArticuloBodega()
        undd = self.Unidad()
        ora = self.Oracle1()
        ora2 = self.Oracle2()
        presentar = f""" 
            <div >
                <p> 
                    <button class='w3-button w3-Deep-Orange w3-hover-Yellow' onclick='presentaPrimerRegistro();'>Primero</button>
                    <button class='w3-button w3-Deep-Orange w3-hover-Yellow' onclick='presentaSiguienteRegistro();'>Siguiente</button>
                    <button class='w3-button w3-Deep-Orange w3-hover-Yellow' onclick='presentaAnteriorRegistro();'>Anterior</button>
                    <button class='w3-button w3-Deep-Orange w3-hover-Yellow' onclick='presentaUltimoRegistro();'>Ultimo</button>
                    <button class='w3-button w3-Teal w3-hover-grey' onclick='Guardar();'>Guardar</button>
                    <button class='w3-button w3-Teal w3-hover-grey' onclick='Editar();'>Editar</button>
                    <button class='w3-button w3-Teal w3-hover-grey' onclick='readOnly();'>Habilitar Fecha Digitacion</button>
                </p>
                <table class='tabla' cellspacing='10'>
                    <tr>
                        <th> Ingreso de Bodega Nro.: </th>
                        <td><input value='lblIngresoNo' name='lblIngresoNo' id='lblIngresoNo' style='background-color:#3498db; color:blue;' type='int' readonly></td>
                    </tr>
                    <tr>
                        <th> proveedor: </th>
                        <td>{proveedor}</td>
                    </tr>
                    <tr>
                        <th> Tipo TRX: </th>
                        <td>{textotipo}</td>
                        <th> Fecha Digitacion </th>
                        <td> <input name='txtfechaDigitacion' id='txtfechaDigitacion' value='fechaDeHoy' readonly> </td>
                    </tr>
                    <tr>
                        <th> Bodega: </th>
                        <td>{textobodega}</td>
                        <th> Fecha Ing Bodega</th>
                        <td> <input name='txtfechaIngBodega' id='txtfechaIngBodega'></td>
                    </tr>
                    <tr>
                        <th> Observacion: </th>
                        <td><input name='txtObservacion' id='txtObservacion' type='text'></td>
                    </tr>
                </table>
            </div>
            <div class='divMuestra' id='divMuestra'>
                
            </div>       
            <div> 
                <table class='grid2' id='tabla' cellspacing='10'>      
                    <tr> 
                        <th class='undM'>Und.Medida:</th>   
                        <th>Cant.Com:</th>   
                        <th>Cant.Bod:</th>
                        <th>Oracle1:</th>     
                    </tr>
                    <tr>
                        <td>{undd}</td>
                        <td><input id='CantCom' style='width:395px; background-color: #008080; text-align: center;'></td>
                        <td><input id='CantBod' style='width:250px; background-color: #008080; text-align: center;'></td>
                        <td>{ora}</td>
                    </tr>
                    <tr>    
                        <th class='articBodega'>Articulo de Bodega:</th>
                        <th>Oracle2:</th>
                        <th>AR:</th>      
                    </tr>
                    <tr>
                        <td>{articulobodega} </td>
                        <td>{ora2}</td>
                        <td><input type="text" id='CtaGastosAR' style='width:250; background-color: #008080; text-align: center;'></td>
                    </tr>
                    <tr>
                        <th class='refer'> Referencia:</th>
                        <th>Descripcion:</th>  
                    </tr>
                    <tr>
                        <td><input type="text" id='referencia1' required></td>  
                        <td><input type="text" id='descripcion' required></td>
                    </tr>
                    <tr>
                        <th>Ubicacion:</th>
                        <th>Total $:</th>  
                    </tr>
                    <tr>
                        <td><input type="text" id='ubicacion' style='width:395px; background-color: #008080; text-align: center;' required></td>  
                        <td><input type="text" id='total' style='width:400px; background-color: #008080; text-align: center;' required></td>
                    </tr>
                </table>
                <p>
                    <button class='w3-button w3-Teal w3-hover-grey' onclick='Agregar();'>Agregar</button>
                    <button class='w3-button w3-Teal w3-hover-grey' onclick='Eliminar();'>Eliminar</button>
                    <button class='w3-button w3-Teal w3-hover-grey' onclick='Renovar();'>Renovar</button>
                    <button class='w3-button w3-Teal w3-hover-grey' onclick='Actualizar();'>Actualizar</button>
                </p>  
            </div>
        """
        presentar += """
            <script>
                let primary=0;
                function presentaPrimerRegistro()
                {
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=presentaPrimerRegistro';
					var content = getContent(purl);
                    console.log(content);
                  // alert(content);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    primary=arreglo[0];
                    document.getElementById('lblIngresoNo').value=arreglo[0];
                    document.getElementById('txtProveedor').value=arreglo[1];
                    document.getElementById('txtTipoTRX').value=arreglo[2];
                    document.getElementById('txtbodega').value=arreglo[3];
                    document.getElementById('txtObservacion').value=arreglo[4];
                    document.getElementById('txtfechaDigitacion').value=arreglo[5];
                    document.getElementById('txtfechaIngBodega').value=arreglo[6]; 
                    presentarDetalle(primary);
                }
                function presentaSiguienteRegistro()
                {
                    parametro="&elPrimary="+primary;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=presentaSiguienteRegistro'+parametro;
					console.log(purl);
                    var content = getContent(purl);
                    console.log(content);
                //   alert(content);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    primary=arreglo[0];
                    document.getElementById('lblIngresoNo').value=arreglo[0];
                    document.getElementById('txtProveedor').value=arreglo[1];
                    document.getElementById('txtTipoTRX').value=arreglo[2];
                    document.getElementById('txtbodega').value=arreglo[3];
                    document.getElementById('txtObservacion').value=arreglo[4];
                    document.getElementById('txtfechaDigitacion').value=arreglo[5];
                    document.getElementById('txtfechaIngBodega').value=arreglo[6];
                    //console.log(primary);
                    presentarDetalle(primary);
                }
                function presentaAnteriorRegistro()
                {
                    parametro="&elPrimary="+primary;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=presentaAnteriorRegistro'+parametro;
					console.log(purl);
                    var content = getContent(purl);
                    console.log(content);
                //   alert(content);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    primary=arreglo[0];
                    document.getElementById('lblIngresoNo').value=arreglo[0];
                    document.getElementById('txtProveedor').value=arreglo[1];
                    document.getElementById('txtTipoTRX').value=arreglo[2];
                    document.getElementById('txtbodega').value=arreglo[3];
                    document.getElementById('txtObservacion').value=arreglo[4];
                    document.getElementById('txtfechaDigitacion').value=arreglo[5];
                    document.getElementById('txtfechaIngBodega').value=arreglo[6];
                    presentarDetalle(primary);
                }
                function presentaUltimoRegistro()
                {
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=presentaUltimoRegistro';
					var content = getContent(purl);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    primary=arreglo[0];
                    document.getElementById('lblIngresoNo').value=arreglo[0];
                    document.getElementById('txtProveedor').value=arreglo[1];
                    document.getElementById('txtTipoTRX').value=arreglo[2];
                    document.getElementById('txtbodega').value=arreglo[3];
                    document.getElementById('txtObservacion').value=arreglo[4];
                    document.getElementById('txtfechaDigitacion').value=arreglo[5];
                    document.getElementById('txtfechaIngBodega').value=arreglo[6];
                    presentarDetalle(primary);
                }
                function presentarDetalle(elPrimary)
                {
                    parametro='&elPrimary='+elPrimary;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=presentaDetalleEgreso'+parametro;
					var content = getContent(purl);
                    divMuestra.innerHTML=content;
                }
                function Guardar()
                {
                    //var idProveedor = document.getElementById('lblIngresoNo').value;
                    var proveedor = document.getElementById('txtProveedor').value;
                    var tipoTRX = document.getElementById('txtTipoTRX').value;
                    var bodega = document.getElementById('txtbodega').value;
                    var observacion = document.getElementById('txtObservacion').value;
                    var fechaDigitacion = document.getElementById('txtfechaDigitacion');
                    var fechaActual = new Date().toISOString().split('T')[0]; 
                    
                    fechaDigitacion.value = fechaActual;
                    var fechaIngBodega = document.getElementById('txtfechaIngBodega').value;
                    var parametro = '&proveedor=' + proveedor + '&tipoTRX=' + tipoTRX + '&bodega=' + bodega + '&observacion=' + observacion + '&fechaDigitacion=' + fechaDigitacion.value + '&fechaIngBodega=' + fechaIngBodega;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=Guardar'+parametro;
                    var content = getContent(purl);
                    console.log(content);
                }
                function Agregar()
                {   
                    var idProveedor = document.getElementById('lblIngresoNo').value;
                    var UndMedida = document.getElementById('UndMedida1').value;
                    var cantCom = document.getElementById('CantCom').value;
                    if (cantCom === '') {
                        alert('Ingrese la Cant. Com: es Obligatorio');
                        return false;
                    }
                    var cantBod = document.getElementById('CantBod').value;
                    if (cantBod === '') {
                        alet('Ingrese la Cant. bom: es Obligatorio');
                    }
                    var Oracle1 = document.getElementById('Oracle1').value;
                    var Oracle2 = document.getElementById('Oracle2').value;
                    var ar = document.getElementById('CtaGastosAR').value;
                    if(ar === ''){
                        alert('INGRESE EL AR: este campo es obligatorio');
                    }
                    var articulodeBodega = document.getElementById('articulodeBodega').value;
                    var referencia1 = document.getElementById('referencia1').value;
                    if (referencia1 === ''){
                        alert('Ingrese la referencia: es obligatorio');
                    }
                    var descripcion = document.getElementById('descripcion').value;
                    if (descripcion === ''){
                        alert('Ingrese la Descripcion: este campo es obligatorio');
                    }
                    var ubicacion = document.getElementById('ubicacion').value;
                    if(ubicacion === ''){
                        alert('INGRESE LA UBICACION: este campo es obligatorio');
                    }
                    var total = document.getElementById('total').value;
                    if (total === ''){
                        alert('INGRESE EL TOTAL: este campo es obligatorio');
                    }
                    var parametro ='&primary='+ primary +'&idProveedor='+ idProveedor +'&UndMedida='+ UndMedida +'&cantCom='+ cantCom +'&cantBod='+ cantBod+'&Oracle1='+ Oracle1 +'&Oracle2='+ Oracle2;
                    parametro = parametro +'&ar='+ ar+'&articulodeBodega='+ articulodeBodega +'&referencia1='+ referencia1 +'&descripcion='+ descripcion +'&ubicacion='+ ubicacion +'&total='+ total;
                    console.log(parametro);
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=Agregar'+parametro;
                    var content = getContent(purl);
                    console.log(content);
                }
                function Eliminar()
                {
                    var idProveedor = document.getElementById('lblIngresoNo').value;
                    var parametro = '&idProveedor=' + idProveedor;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=Eliminar'+parametro;
                    var content = getContent(purl);
                    console.log(content);
                }
                function Renovar() {
                    parametro="&elPrimary="+primary;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=Renovar'+parametro;
					console.log(purl);
                    var content = getContent(purl);
                    console.log(content);
                //   alert(content);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    primary=arreglo[0];
                    document.getElementById('lblIngresoNo').value=arreglo[0];
                    document.getElementById('UndMedida1').value=arreglo[1];
                    document.getElementById('CantCom').value=arreglo[2];
                    document.getElementById('CantBod').value=arreglo[3];
                    document.getElementById('Oracle1').value=arreglo[4];
                    document.getElementById('Oracle2').value=arreglo[5];
                    document.getElementById('CtaGastosAR').value=arreglo[6];
                    document.getElementById('articulodeBodega').value=arreglo[7];
                    document.getElementById('referencia1').value=arreglo[8];
                    document.getElementById('descripcion').value=arreglo[9];
                    document.getElementById('ubicacion').value=arreglo[10];
                    document.getElementById('total').value=arreglo[11];
                }
                
                function Actualizar()
                {   
                    var idProveedor = document.getElementById('lblIngresoNo').value;
                    var UndMedida = document.getElementById('UndMedida1').value;
                    var cantCom = document.getElementById('CantCom').value;
                    var cantBod = document.getElementById('CantBod').value;
                    var Oracle1 = document.getElementById('Oracle1').value;
                    var Oracle2 = document.getElementById('Oracle2').value;
                    var ar = document.getElementById('CtaGastosAR').value;
                    var articulodeBodega = document.getElementById('articulodeBodega').value;
                    var referencia1 = document.getElementById('referencia1').value;
                    var descripcion = document.getElementById('descripcion').value;
                    var ubicacion = document.getElementById('ubicacion').value;
                    
                    var total = document.getElementById('total').value;
                    
                    var parametro = '&idProveedor='+ idProveedor +'&UndMedida='+ UndMedida +'&cantCom='+ cantCom +'&cantBod='+ cantBod +'&Oracle1='+ Oracle1 +'&Oracle2='+ Oracle2;
                    parametro = parametro +'&ar='+ ar +'&articulodeBodega='+ articulodeBodega +'&referencia1='+ referencia1 +'&descripcion='+ descripcion +'&ubicacion='+ ubicacion +'&total='+ total;
                    console.log(parametro);
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=Actualizar'+parametro;
                    var content = getContent(purl);
                    console.log(content);
                }
                function readOnly()
                {
                    var confirmacion = confirm('¡Esta seguro que desea editar la fecha de digitacion!');
                    if (confirmacion){
                        document.getElementById('txtfechaDigitacion').readOnly=false;
                    } else{
                        document.getElementById('txtfechaDigitacion').readOnly=false;
                    } 
                } 
                function Editar()
                {
                    var idProveedor = document.getElementById('lblIngresoNo').value;
                    var proveedor = document.getElementById('txtProveedor').value;
                    var tipoTRX = document.getElementById('txtTipoTRX').value;
                    var bodega = document.getElementById('txtbodega').value;
                    var observacion = document.getElementById('txtObservacion').value;
                    var fechaDigitacion = document.getElementById('txtfechaDigitacion');
                    var fechaActual = new Date().toISOString().split('T')[0]; 
                    fechaDigitacion.value = fechaActual;
                    var fechaIngBodega = document.getElementById('txtfechaIngBodega').value;
                    var parametro = '&idProveedor=' + idProveedor + '&proveedor=' + proveedor + '&tipoTRX=' + tipoTRX + '&bodega=' + bodega + '&observacion=' + observacion + '&fechaDigitacion=' + fechaDigitacion.value + '&fechaIngBodega=' + fechaIngBodega;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=Editar'+parametro;
                    console.log(purl);
                    var content = getContent(purl);
                    console.log(content);
                }
                function btnEditarDetalle(idDetalle)
                {
                    var parametro = '&idDetalle=' + idDetalle;
                    var purl='./librerias/claseBuscar.py?action=ejecutarAJAX&programa=claseIngresos&subPrograma=EditarDetalle'+parametro;
					console.log(purl);
                    var content = getContent(purl);
                    var arreglo=content.split('_sc_');
                    if (arreglo[0] == 0)
                    {
                     //   alert('No existen registros');
                        return;
                    }
                    document.getElementById('UndMedida1').value=arreglo[0];
                    document.getElementById('CantCom').value=arreglo[1];
                    document.getElementById('CantBod').value=arreglo[2];
                    document.getElementById('Oracle1').value=arreglo[3];
                    document.getElementById('Oracle2').value=arreglo[4];
                    document.getElementById('CtaGastosAR').value=arreglo[5];
                    document.getElementById('articulodeBodega').value=arreglo[6];
                    document.getElementById('referencia1').value=arreglo[7];
                    document.getElementById('descripcion').value=arreglo[8];
                    document.getElementById('ubicacion').value=arreglo[9];
                    document.getElementById('total').value=arreglo[10]; 
                    disableObjects();              
                }
                function enableObjects()
                {
                    document.getElementById('UndMedida1').disabled=true;
                    document.getElementById('CantCom').readOnly=false; 
                    document.getElementById('CantBod').readOnly=false;
                    document.getElementById('Oracle1').disabled=true;
                    document.getElementById('Oracle2').disabled=true;
                    document.getElementById('CtaGastosAR').readOnly=false;
                    document.getElementById('articulodeBodega').disabled=true;
                    document.getElementById('referencia1').readOnly=false;
                    document.getElementById('descripcion').readOnly=false;
                    document.getElementById('ubicacion').readOnly=false;
                    document.getElementById('total').readOnly=false;
                }
                function disableObjects()
                {
                    document.getElementById('UndMedida1').disabled=false;
                    document.getElementById('UndMedida1').style.background='#ffff33';
                    document.getElementById('CantCom').readOnly=true;
                    document.getElementById('CantCom').style.background='#ffff33';
                    document.getElementById('CantBod').readOnly=true;
                    document.getElementById('CantBod').style.background='#ffff33';
                    document.getElementById('Oracle1').disabled=false;
                    document.getElementById('Oracle1').style.background='#ffff33';
                    document.getElementById('Oracle2').disabled=false;
                    document.getElementById('Oracle2').style.background='#ffff33';
                    document.getElementById('CtaGastosAR').readOnly=true;
                    document.getElementById('CtaGastosAR').style.background='#ffff33'
                    document.getElementById('articulodeBodega').disabled=false;
                    document.getElementById('articulodeBodega').style.background='#ffff33'
                    document.getElementById('referencia1').readOnly=true;
                    document.getElementById('referencia1').style.background='#ffff33'
                    document.getElementById('descripcion').readOnly=true;
                    document.getElementById('descripcion').style.background='#ffff33'
                    document.getElementById('ubicacion').readOnly=true;
                    document.getElementById('ubicacion').style.background='#ffff33'
                    document.getElementById('total').readOnly=true;
                    document.getElementById('total').style.background='#ffff33';
                }
                presentaUltimoRegistro();
            </script>
        """
        return presentar

    def presentaPrimerRegistro():
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Select nroIngrBodega, proveedor, tipoTrx, codBodega, observacion, fechaIngreso, fechaLLegadaBodega from ingbodegaencabezado order by nroIngrBodega asc limit 1")
        myresult = mycursor.fetchall()
        texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_"
        for x in myresult:
            id=str(x[0])
            proveedor=str(x[1])
            tipoTrx=str(x[2])
            codBodega=str(x[3])
            observacion=x[4]
            fechaEgreso=str(x[5])
            fechaEgreBodega=str(x[6])
            texto= "" + id + "_sc_" + proveedor + "_sc_" + tipoTrx + "_sc_" + codBodega + "_sc_" + observacion + "_sc_" + fechaEgreso + "_sc_" + fechaEgreBodega + "_sc_"
        return texto
    
    def presentaSiguienteRegistro():
        form = cgi.FieldStorage()
        elPrimary = str(form["elPrimary"].value)
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Select nroIngrBodega, proveedor, tipoTrx, codBodega, observacion, fechaIngreso, fechaLLegadaBodega from ingbodegaencabezado where nroIngrBodega > " + elPrimary + " order by nroIngrBodega asc limit 1")
        myresult = mycursor.fetchall()
        texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_"
        for x in myresult:
            id=str(x[0])
            proveedor=str(x[1])
            tipoTrx=str(x[2])
            codBodega=str(x[3])
            observacion=x[4]
            fechaEgreso=str(x[5])
            fechaEgreBodega=str(x[6])
            texto= "" + id + "_sc_" + proveedor + "_sc_" + tipoTrx + "_sc_" + codBodega + "_sc_" + observacion + "_sc_" + fechaEgreso + "_sc_" + fechaEgreBodega + "_sc_"
        return texto
    
    def presentaAnteriorRegistro():
        form = cgi.FieldStorage()
        elPrimary = str(form["elPrimary"].value)
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Select nroIngrBodega, proveedor, tipoTrx, codBodega, observacion, fechaIngreso, fechaLLegadaBodega FROM ingbodegaencabezado where nroIngrBodega < " + elPrimary + " order by nroIngrBodega desc limit 1")
        myresult = mycursor.fetchall()
        texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_"
        for x in myresult:
            id=str(x[0])
            departamento=str(x[1])
            tipoTrx=str(x[2])
            codBodega=str(x[3])
            observacion=x[4]
            fechaEgreso=str(x[5])
            fechaEgreBodega=str(x[6])
            texto= "" + id + "_sc_" + departamento + "_sc_" + tipoTrx + "_sc_" + codBodega + "_sc_" + observacion + "_sc_" + fechaEgreso + "_sc_" + fechaEgreBodega + "_sc_"
        return texto
    
    def presentaUltimoRegistro():
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Select nroIngrBodega, proveedor, tipoTrx, codBodega, observacion, fechaIngreso, fechaLLegadaBodega from ingbodegaencabezado order by nroIngrBodega desc limit 1")
        myresult = mycursor.fetchall()
        texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_"
        for x in myresult:
            id=str(x[0])
            proveedor=str(x[1])
            tipoTrx=str(x[2])
            codBodega=str(x[3])
            observacion=x[4]
            fechaEgreso=str(x[5])
            fechaEgreBodega=str(x[6])
            texto= "" + id + "_sc_" + proveedor + "_sc_" + tipoTrx + "_sc_" + codBodega + "_sc_" + observacion + "_sc_" + fechaEgreso + "_sc_" + fechaEgreBodega + "_sc_"
        return texto
    def presentaDetalleEgreso():
        form = cgi.FieldStorage()
        elPrimary= str(form["elPrimary"].value)
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT itemBodega, nombreDepartamento, cantidadUnd, itemCompra, descripcionBodega, cantidad FROM ingbodegadetalle WHERE nroIngrBodega=" + elPrimary + " order by itemBodega")
        myresult = mycursor.fetchall()
        lista= "" 
        for x in myresult:
            id=str(x[0])
            NroCompra=str(x[2])
            ItemCompra=str(x[3])
            Descripcion=x[4]
            Cantidad=str(x[5])
            lista += "<tr class='Progra'>"
            lista +="<td> <button id=btn_'"+ id +"' onclick='btnEditarDetalle("+ id +");'>Editar </button></td> "
            lista += "<td id='id'>"  + id + "</td>" 
            lista += "<td>" + NroCompra + "</td>" 
            lista += "<td>" + ItemCompra + "</td>"
            lista += "<td>" + Descripcion + "</td>"
            lista += "<td>" + Cantidad + "</td>"
            lista +="</tr>"
        presenta = "<table border='1'>"
        presenta += "<tr>"
        presenta += "<th>Accion</th>" 
        presenta += "<th>Item Bodega</th>" 
        presenta += "<th>Nro. Compra</th>"
        presenta += "<th>Item Compra</th>"
        presenta += "<th>Descripcion</th>"
        presenta += "<th>Cantidad</th>"
        presenta +="</tr>"
        presenta += lista
        presenta += "</table>"
        return presenta
        
    def Guardar():
        form = cgi.FieldStorage()
        #id = form.getvalue("idProveedor")
        proveedor = form.getvalue("proveedor")
        tipoTRX = form.getvalue("tipoTRX")
        Bodega = form.getvalue("bodega")
        observacion = form.getvalue("observacion")
        fechaDigitacion = form.getvalue("fechaDigitacion")
        fechaEgreBodg = form.getvalue("fechaIngBodega")
        #return id, departamento, tipoTRX, Bodega, observacion, fechaDigitacion, fechaEgreBodg
        coneccion = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mro.ordenprueba"
        )
        mycursor = coneccion.cursor()
        sql = "INSERT INTO ingbodegaencabezado (proveedor, tipoTrx, codBodega, observacion, fechaIngreso, fechaLLegadaBodega) VALUES (%s, %s, %s, %s, %s, %s)"
        values = (proveedor, tipoTRX, Bodega, observacion, fechaDigitacion, fechaEgreBodg)
        mycursor.execute(sql, values)
        coneccion.commit()  
        return values

    def Agregar():
        form = cgi.FieldStorage()
        primary = form.getvalue("primary")
        idProveedor = form.getvalue("idProveedor")
        UndMedida = form.getvalue("UndMedida")
        cantCom = form.getvalue("cantCom")
        cantBod = form.getvalue("cantBod")
        Oracle1 = form.getvalue("Oracle1")
        Oracle2 = form.getvalue("Oracle2")
        ar = form.getvalue("ar")
        articulodeBodega = form.getvalue("articulodeBodega")
        referencia1 = form.getvalue("referencia1")
        descripcion = form.getvalue("descripcion")
        ubicacion = form.getvalue("ubicacion")
        total = form.getvalue("total")
        #return primary,idProveedor, UndMedida, cantCom, cantBod, Oracle1, Oracle2, ar, articulodeBodega, referencia1, descripcion, ubicacion, total 
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="mro.ordenprueba"
        )
        cursor = conexion.cursor()                                               
        cursor.execute ("INSERT INTO ingbodegadetalle (nroIngrBodega, codArticulo, unidad, cantidadUnd, cantidad, oracleuno, oracledos, ar, codArtBod, referencia, descripcionBodega, ubicacion, total) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", (primary , idProveedor, UndMedida, cantCom, cantBod, Oracle1, Oracle2, ar, articulodeBodega, referencia1, descripcion, ubicacion, total ))	
        conexion.commit()
        conexion.close()
        return 'coneccion exitosa'
    
    def Actualizar():
        form = cgi.FieldStorage()
        idProveedor = form.getvalue('idProveedor')
        UndMedida = form.getvalue('UndMedida')
        cantCom = form.getvalue('cantCom')
        cantBod = form.getvalue('cantBod')
        Oracle1 = form.getvalue('Oracle1')
        Oracle2 = form.getvalue('Oracle2')
        ar = form.getvalue('ar')
        articulodeBodega = form.getvalue('articulodeBodega')
        referencia1 = form.getvalue('referencia1')
        descripcion = form.getvalue('descripcion')
        ubicacion = form.getvalue('ubicacion')
        total = form.getvalue('total')
        #return idProveedor, UndMedida, cantCom, cantBod, Oracle1, Oracle2, ar, articulodeBodega, referencia1, descripcion, ubicacion, total
        conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='mro.ordenprueba'
        )
        cursor = conexion.cursor()
        cursor.execute("Update ingbodegadetalle SET unidad=%s, cantidadUnd=%s, cantidad=%s, oracleuno=%s, oracledos=%s, ar=%s, codArtBod=%s, referencia=%s, descripcionBodega=%s, ubicacion=%s, total=%s WHERE itemBodega=%s", (UndMedida, cantCom, cantBod, Oracle1, Oracle2, ar, articulodeBodega, referencia1, descripcion, ubicacion, total, idProveedor))
        conexion.commit()
        conexion.close()
        return 'Se actualizo'
    
    def Renovar():
        form = cgi.FieldStorage()
        elPrimary = str(form["elPrimary"].value)
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Select idtrx, unidad, cantidad,  ar, codArticulo, codArtBod, ubicacion, referencia, descripcionBodega from egrbodegadetalle where idtrx > " + elPrimary + " order by idtrx asc limit 1")
        myresult = mycursor.fetchall()
        texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_" + "_sc_"
        for x in myresult:
            EgresoBodegaNo=str(x[0])
            UndMedida=str(x[1])
            cantidad1=str(x[2])
            CtaGastosAR=x[3]
            art=str(x[4])
            articulodeBodega=str(x[5])
            ubicacion1=x[6]
            referencia1=x[7]
            descripcion=x[8]
            texto= "" +EgresoBodegaNo + "_sc_" + UndMedida + "_sc_" + cantidad1 + "_sc_" + CtaGastosAR + "_sc_" + art + "_sc_" + articulodeBodega + "_sc_" + ubicacion1 + "_sc_" + referencia1 + "_sc_" + descripcion + "_sc_"
            print(texto)
        return texto
    def Eliminar():
        form = cgi.FieldStorage()
        idProveedor = form.getvalue("idProveedor")
        #return idProveedor
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="mro.ordenprueba"
        )
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM ingbodegadetalle WHERE itemBodega IN (SELECT nroIngrBodega FROM  ingbodegaencabezado WHERE nroIngrBodega=%s)",(idProveedor,))
        conexion.commit()
        conexion.close()
        return 'Se elimino exitosamente'
        
    def EditarDetalle():
        form = cgi.FieldStorage()
        idDetalle= form.getvalue("idDetalle")
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT  itemBodega, unidad, cantidad, cantidadUnd, oracleuno, oracledos, ar, codArtBod, referencia, descripcionBodega, ubicacion, total FROM ingbodegadetalle WHERE itemBodega=" + idDetalle + " limit 1 ")
        myresult = mycursor.fetchall()
        #texto= "0" + "_sc_" + "_sc_" + "_sc_"+ "_sc_" + "_sc_" + "_sc_" + "_sc_" + "_sc_"
        #return texto
        for x in myresult:
            UndMedida1=str(x[1])
            CantCom=str(x[2])
            CantBod=str(x[3])
            Oracle1=x[4] 
            Oracle2=x[5]
            CtaGastosAR=x[6]
            articulodeBodega=str(x[7]) 
            referencia1=x[8]
            descripcion=x[9]
            ubicacion=x[10]
            total=str(x[11])
            texto = "" +UndMedida1 + "_sc_" +CantCom+ "_sc_" +CantBod+ "_sc_" +Oracle1+ "_sc_" +Oracle2+ "_sc_" +CtaGastosAR+ "_sc_" +articulodeBodega+ "_sc_" +referencia1+ "_sc_" +descripcion+ "_sc_" +ubicacion+ "_sc_" +total+ "_sc_"
        return texto
    def Editar():
        form = cgi.FieldStorage()
        nroIngBodega = form.getvalue("idProveedor")
        proveedor = form.getvalue("proveedor")
        tipoTRX = form.getvalue("tipoTRX")
        Bodega = form.getvalue("bodega")
        observacion = form.getvalue("observacion")
        fechaDigitacion = form.getvalue("fechaDigitacion")
        fechaEgreBodg = form.getvalue("fechaIngBodega")
        #return nroIngBodega, proveedor, tipoTRX, Bodega, observacion, fechaDigitacion, fechaEgreBodg
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="mro.ordenprueba"
        )
        mycursor = mydb.cursor()
        mycursor.execute("UPDATE ingbodegaencabezado SET proveedor=%s, tipoTrx=%s, codBodega=%s, observacion=%s, fechaIngreso=%s, fechaLLegadaBodega=%s WHERE nroIngrBodega=%s", (proveedor, tipoTRX, Bodega, observacion, fechaDigitacion, fechaEgreBodg, nroIngBodega))
        mydb.commit()
        return mycursor